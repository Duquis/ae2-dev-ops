user = 
password = 
client_id = 
server = "mqtt.mydevices.com"
port = 1883
