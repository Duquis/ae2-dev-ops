temp = 25
aquecimento = "desligado"
sistema = "ON"

def aquecedor(estado: str):
    global aquecimento, sistema
    if estado == "on":
        sistema = "ON"
    elif estado == "off":
        sistema = "OFF"

def temperatura():
    global temp, aquecimento, sistema
    print("Sistema de controle de temperatura estufa 1: " + str(sistema))
    print("Temperatura: " + str(temp) + "ºC")
    print("Aquecedor: " + str(aquecimento))
    print("________________________________________\n")
    if sistema == "ON" and temp <= 20:
        aquecimento = "ligado"
    elif temp >= 30:
        aquecimento = "desligado"
    elif sistema == "OFF":
        aquecimento = "desligado"
        pass
    if aquecimento == "ligado":
            temp += 2
    elif aquecimento == "desligado":
            temp -= 2
    
    return(temp)
    

